1. For Linux, type: 
       
       make -f Make.LINUX
   
   to compile RoBoIO library, and type: 
   
       make rcdemo -f Make.LINUX
   
   to compile RoBoRC (the RoBoard RC servo Demo).

2. for DOS DJGPP, type: 

       make -f Make.DJ
       
   to compile RoBoIO library, and type:
   
       make rcdemo -f Make.DJ
       
   to compile RoBoRC (the RoBoard RC servo Demo).


