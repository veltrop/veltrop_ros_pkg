// Roboard Demo.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#if defined(RB_MSVC_WIN32) || defined(RB_MSVC_WINCE)
//    #include <windows.h>
//#endif

#ifdef USE_RBDLL
	#define  USE_COMMON
	#include <roboard_dll.h>
#else
	#define  USE_COMMON
	#include <roboard.h>
#endif
#include "userio.h"
#include "demofile.h"

#if defined(RB_LINUX)
    #define _stricmp  strcasecmp
    #define _strnicmp strncasecmp
#elif defined(RB_BC_DOS) || defined(RB_DJGPP)
    #define _stricmp  stricmp
    #define _strnicmp strnicmp
#endif


static bool overwrite   = false;
static bool realtime    = false;
static bool showmessage = true;
static unsigned long replaytime = 1000L; //1000ms

#if defined(RB_MSVC_WIN32)
    //#define USE_SOUND
#endif

#ifdef USE_SOUND
	#include "fileio.h"
    #include <irrKlang.h>
    using namespace irrklang;

	class CMyFileFactory : public irrklang::IFileFactory
	{
	public:
		virtual irrklang::IFileReader* createFileReader(const ik_c8* filename)
		{
			FILEIO* file = fileio_FileOpen((char*)filename, "rb");
			if (!file) return 0;

			return new CMyReadFile(file, filename);
		}

	protected:
		class CMyReadFile : public irrklang::IFileReader
		{
		public:
			CMyReadFile(FILEIO* openedFile, const ik_c8* filename)
			{
				File = openedFile;
				strcpy(Filename, filename);
				FileSize = (ik_s32)fileio_GetSize(openedFile);
			}

			~CMyReadFile()
			{
				fileio_FileClose(File);
			}

			ik_s32 read(void* buffer, ik_u32 sizeToRead)
			{
				return (ik_s32)fileio_Read(buffer, 1, sizeToRead, File);
			}

			bool seek(ik_s32 finalPos, bool relativeMovement)
			{
				return fileio_Seek(File, finalPos, relativeMovement ? SEEK_CUR : SEEK_SET) == 0;
			}

			ik_s32 getSize()
			{
				return FileSize;
			}

			ik_s32 getPos()
			{
				return fileio_GetPos(File);
			}

			const ik_c8* getFileName()
			{
				return Filename;
			}

			FILEIO* File;
			char Filename[1024];
			ik_s32 FileSize;

		}; //end class CMyReadFile
	}; //end class CMyFileFactory
#endif


static int servo_idx = 1;
static int servo[] =
    {
        RCSERVO_SERVO_DEFAULT,
        RCSERVO_KONDO_KRS78X,
        RCSERVO_HITEC_HSR8498
    };
static char* servo_name[] =
    {
        "Default Servo",
        "KONDO KRS-786 & KRS-788",
        "HiTEC HSR-8498HB"
    };

static bool init_rcservo(unsigned long channels) {
	int i;

	showmsg("Initializing RCSERVO lib (for %s)...", servo_name[servo_idx]);
	for (i=0; i<32; i++) rcservo_SetServo(i, servo[servo_idx]);

	if (rcservo_Initialize(channels) == true)
	{
		showmsg("...success\n");
		rcservo_EnableMPOS();
		rcservo_SetFPS(100);
		return true;
	}

	showmsg("...fail!\n");
	errmsg("ERROR: RCSERVO lib fails to initialize (%s)!\n", roboio_GetErrMsg());
	return false;
}

static void close_rcservo(void) {
	showmsg("Closing RCSERVO lib...");
	rcservo_Close();
	showmsg("...done\n");
}

static unsigned long htol(char* str) {
    unsigned long value = 0L;

	for (int i=0; i<(int)strlen(str); i++)
		value = (str[i]>'9')? value*16+(unsigned long)(str[i]-'a'+10): value*16+(unsigned long)(str[i]-'0');

	return value;
}

static void writefile_frame(FILE* fp, unsigned long* width, int frameno) {
	int i;

	if (frameno != -1) fprintf(fp, "[Frame %d]\n", frameno);
	for (i=0; i<32; i++)
		fprintf(fp, "channel%d = %lu\n", i, width[i]);
	if (frameno != -1) fprintf(fp, "\n");
}



void mode_captureframes(char* filename, int frameno, unsigned long usedchannels) {
	unsigned long width[32], nowtime;
	unsigned c = 0;
	int i;
	FILE* fp;

	showmsg("Open %s to write...", filename);
	if (overwrite == false) //&&
	if ((fp = fopen(filename, "r")) != NULL)
	{
		fclose(fp);
		showmsg(" file already exists. overwirte? (Y/N) ");
		c = keyboard_waitkey();
		if ((c != 'y') && (c != 'Y'))
		{
			showmsg("...abort!\n");
			return;
		}
	}

	if ((fp = fopen(filename, "w")) == NULL)
	{
		showmsg("...fail!\n");
		return;
	}
	showmsg("...success\n");

	if (init_rcservo(usedchannels) == false) return; else showmsg("\n");
	for (i=0; i<32; i++)
		rcservo_SetServoType(i, RCSERVO_SV_FEEDBACK, RCSERVO_FB_FASTMODE + RCSERVO_FB_DENOISE);

	rcservo_EnterCaptureMode();
	nowtime = timer_nowtime();
	while (1)
	{
		if ((realtime != true) || (showmessage == true))
			showmsg("Pose the KONDO robot, and press any key to capture [ESC to quit] ...\n");

		if ((realtime == true) && (frameno != -1))
		{
		    do
            {
                c = keyboard_getkey();
            } while (((timer_nowtime() - nowtime) < replaytime) && (c != KBESC));
			nowtime = timer_nowtime();
		}
		else
			c = keyboard_waitkey();

		if (c == KBESC) break;

		rcservo_ReadPositions(usedchannels, RCSERVO_CMD_POWEROFF, width);
		for (i=0; i<32; i++)
		{
			if (width[i] == 0xffffffffL)
			{
				showmsg("ERROR: fail to read the position of channel %d!\n", i);
				width[i] = 0L;
			}
			else
			{
		        if ((realtime == false) || (frameno == -1) || (showmessage == true))
				    showmsg("The position of channel %d is %lu\n", i, width[i]);
			}
		}//end for i...
		writefile_frame(fp, width, frameno);

		if (frameno == -1) break;

		if ((realtime != true) || (showmessage == true))
			showmsg("[Frame %d] captured\n\n", frameno);
		frameno++;
	}

	fclose(fp);
	close_rcservo();
}



#ifdef RB_BC_DOS
	#define MAXFRAMES	(999)
#else
	#define MAXFRAMES	(9999)
#endif
void mode_replayframes(char* filename, int frameno, unsigned long usedchannels) {
	unsigned long* frmPool[MAXFRAMES];
	int   i;
	bool  r;

	DEMOFILE_demoDirectory = "";
	demofile_InitFRM(frmPool, MAXFRAMES);
	if (frameno == -1)
	{
		showmsg("Read the frame from %s...", filename);
		r = demofile_ReadSingleFRM(filename, &(frmPool[0]));
	}
	else
	{
		showmsg("Read frames from %s...", filename);
		r = demofile_ReadFRM(filename, frmPool, MAXFRAMES);
	}

	if (r == false)
	{
		showmsg("...fail! (%s)\n", roboio_GetErrMsg());
		demofile_FreeFRM(frmPool, MAXFRAMES);
		return;
	}
	showmsg("...success\n");

	if (init_rcservo(usedchannels) == false) return; else showmsg("\n");

	rcservo_EnterPlayMode();
	for (i=(frameno==-1)?0:frameno; i<MAXFRAMES; i++)
	{
		if (frmPool[i] == NULL) continue;

		if ((realtime != true) || (showmessage == true))
			showmsg("Playing [Frame %d]...", i);

		rcservo_MoveTo(frmPool[i], replaytime);

		if ((realtime != true) || (showmessage == true))
			showmsg("...finish\n");

		if ((frameno == -1) || (i == MAXFRAMES-1))
		{
			showmsg("press any key to quit\n\n");
			keyboard_waitkey();
			break;
		}
		else
		if ((realtime != true) || (showmessage == true))
			showmsg("press any key to continue [ESC to quit]\n\n");

		if (realtime == true)
		{
			if (keyboard_getkey() == KBESC) break;
		}
		else
		{
			if (keyboard_waitkey() == KBESC) break;
		}
	}//end for (i...

	showmsg("Finish the replay process.\n");
	demofile_FreeFRM(frmPool, MAXFRAMES);

	close_rcservo();
}



static struct {char* keyname; unsigned keyvalue;} CMD_specialKey[] =
	{
        {"F1",    KBF1},
        {"F2",    KBF2},
        {"F3",    KBF3},
        {"F4",    KBF4},
        {"F5",    KBF5},
        {"F6",    KBF6},
        {"F7",    KBF7},
        {"F8",    KBF8},
        {"F9",    KBF9},
        {"F10",   KBF10},
        {"F11",   KBF11},
        {"F12",   KBF12},
        {"ENTER", KBENTER},
        {"UP",    KBUP},
        {"DOWN",  KBDOWN},
        {"LEFT",  KBLEFT},
        {"RIGHT", KBRIGHT},
        {"PGUP",  KBPGUP},
        {"PGDN",  KBPGDN}
	};
#define NUM_SPECIALKEY  (sizeof(CMD_specialKey)/sizeof(CMD_specialKey[0]))
static char* cmdtostr(unsigned cmd) {
	static char cmdstr[2] = {'\0', '\0'};
	int i;

	for (i=0; i<(int)NUM_SPECIALKEY; i++)
		if (cmd == CMD_specialKey[i].keyvalue) return CMD_specialKey[i].keyname;

	cmdstr[0] = (char)cmd;
	return cmdstr;
}

void mode_playdemo(char* dirname, unsigned long idletime) {
	char  demodir[255];
	char  demodef[255];
	int   i;
	unsigned c;

	DEF_t  demo;
	ACT_t* curact;

	#define NOPLAY		(0)
	#define PLAYNEXT	(1)
	#define PLAYING		(2)
	int  playing = NOPLAY;
	bool playpause;
	unsigned long idleTimeOut = timer_nowtime();
	unsigned long playframe[32];

	strcpy(demodir, dirname);
	strcat(demodir, "/");
	DEMOFILE_demoDirectory = demodir;

	while (strcspn(dirname, "/\\") != strlen(dirname)) dirname = &dirname[strcspn(dirname, "/\\") + 1];
	strcpy(demodef, dirname);
	strcat(demodef, ".def");

	showmsg("Loading demo: %s\n-----------------------------------\n", dirname);
	if (demofile_ReadDEF(demodef, &demo) == false)
	{
		showmsg("Fail to load (%s)!\n", roboio_GetErrMsg());
		return;
	}
	showmsg("-----------------------------------> completed\n");

	if (init_rcservo(demo.usedChannels) == false) return;
	for (i=0; i<32; i++) rcservo_SetServoParams1(i, demo.PWMPeriod, demo.minPWMDuty, demo.maxPWMDuty);

    #ifdef USE_SOUND
	   showmsg("Initializing Audio...");
	   ISoundEngine* audioEngine = createIrrKlangDevice(ESOD_AUTO_DETECT, ESEO_MULTI_THREADED | ESEO_LOAD_PLUGINS);
	   if (!audioEngine)
		   showmsg("...fail to initialize audio!\n");
	   else
	   {
		   showmsg("...success\n\n");

		   //allow the audioEngine to read audio files in a zipped file
		   CMyFileFactory* demofileFactory = new CMyFileFactory();
		   audioEngine->addFileFactory(demofileFactory);
		   demofileFactory->drop();
	   }
	#endif

	showmsg("\nCommand List\n=============\n");
	for (i=0; i<demo.CMD_num; i++)
		showmsg("key: %5s  (%s)\n", cmdtostr(demo.cmdPool[i]->command), demo.cmdPool[i]->name);

	showmsg("\nPress one command to play the action ([ESC] to quit)...\n");
	while ((c = keyboard_getkey()) != KBESC)
	{
		if (demo.initCMD != -1)
		{
			c = demo.cmdPool[demo.initCMD]->command;
			demo.initCMD = -1;
		}

		switch (playing)
		{
			case NOPLAY:
				if (timer_nowtime() >= idleTimeOut) rcservo_EnterCaptureMode();  //stop PWM output

				if (c == 0)
					break;
				else
				{
					for (i=0; i<demo.CMD_num; i++)
						if (c == demo.cmdPool[i]->command) break;
					if (i >= demo.CMD_num) break;
				}

				showmsg("Playing command: %s", demo.cmdPool[i]->name);
				curact = demo.actPool[demo.cmdPool[i]->actno];
				if (curact == NULL)
					showmsg("...WARNING: invalid action!\n");
				else
				{
					showmsg("\n");
					rcservo_EnterPlayMode();
					playing   = PLAYNEXT;
					playpause = false;
				}
				break;
			case PLAYNEXT:
				if (curact == NULL)
				{
					showmsg("Finish the action.\n");
					showmsg("\nPress a command to play an action ([ESC] to quit)...\n");
					playing = NOPLAY;
					idleTimeOut = timer_nowtime() + idletime;
                   #ifdef USE_SOUND
						if (audioEngine) audioEngine->removeAllSoundSources();
					#endif
					break;
				}

				switch (curact->type)
				{
					case ACT_PLAYFRAME:
						showmsg("  Move to an old-format frame...");
						for (i=0; i<32; i++) playframe[demo.channelMapping[i]] = curact->data.frame[i];
						rcservo_SetAction(playframe, curact->time);
						playing = PLAYING;
						break;
					case ACT_PLAYFRAMENO:
						showmsg("  Move to [Frame %d]...", curact->data.frameno);
						if (demo.frmPool[curact->data.frameno] == NULL)
							showmsg("WARNING: invalid frame!\n");
						else
						{
							for (i=0; i<32; i++) playframe[demo.channelMapping[i]] = demo.frmPool[curact->data.frameno][i];
							rcservo_SetAction(playframe, curact->time);
							playing = PLAYING;
						}
						break;
					case ACT_PAUSE:
						showmsg("  Pause %ld ms...", curact->time);
	                    for (i=0; i<32; i++) playframe[i] = 0L;
						rcservo_SetAction(playframe, curact->time);
						playing = PLAYING;
						break;
					case ACT_PLAYSND:
						showmsg("  Play Audio %s...", curact->data.filename);
                        #ifdef USE_SOUND
						  if (!audioEngine)
							 showmsg("no audio device!");
						  else
							 audioEngine->play2D(curact->data.filename, false, false, true);
						#else
                             showmsg("no audio support!");
						#endif
						showmsg("\n");
						break;
				}//end switch (curact->type)
				curact = curact->next;
				break;
			case PLAYING:
				if (c == KBEND)
				{
					showmsg("Stop\n");
					playing = PLAYNEXT;
					curact  = NULL;
					break;
				}
				else
				if (c == KBSPACE)
				{
					playpause = (playpause == false)? true : false;
					if (playpause == false)
					{
						showmsg("Play.");
						rcservo_ReleaseAction();
					}
					else
					{
						showmsg("Paused.");
						rcservo_PauseAction();
					}
				}

				if (rcservo_PlayAction() == RCSERVO_PLAYEND)
				{
					showmsg("\n");
					playing = PLAYNEXT;
				}
				break;
		}//end switch (playing)
	}//end while ((c = keyboard_getkey()...
	if (playing == PLAYING) showmsg("\n");

	demofile_FreeDEF(&demo);
    #ifdef USE_SOUND
		if (audioEngine) audioEngine->drop();
	#endif
	close_rcservo();
}



void showhelp(void) {
	showmsg("Parameters\n");
	showmsg("===========\n");
	showmsg("-CH xxxxxxxx or --channels xxxxxxxx:\n");
    showmsg("    Specify the PWM channels to use\n");
	showmsg("    \n");
	showmsg("-t xxxx or --time xxxx:\n");
    showmsg("    Specify the time for realtime frame capture,\n");
    showmsg("    frame replay, and demo play\n");
	showmsg("    \n");
	showmsg("-SV [Generic, KONDO, HiTEC] or --servo [Generic, KONDO, HiTEC]:\n");
    showmsg("    Specify servo motors\n");
	showmsg("    \n");
	showmsg("-OW or --overwrite:\n");
    showmsg("    Always overwrite the file of storing captured frames\n");
	showmsg("    \n");
	showmsg("-NM or --nomessage:\n");
    showmsg("    Not display messages when capturing or replaying frames,\n");
    showmsg("    being useful to speed up CAPTURE_RT and REPLAYS_RT modes\n");

	showmsg("\n");
	showmsg("[press any key to continue...]\n"); keyboard_waitkey();
	showmsg("\n");

	showmsg("Usage examples\n");
	showmsg("===============\n");
	showmsg("RoBoRC.exe CAPTURE(or 0) 0000.txt -CH 000000ff:\n");
    showmsg("    Capture a single frame of servo positions on channels 0~7.\n");
    showmsg("    The frame is saved to 0000.txt.\n");
	showmsg("    \n");
	showmsg("RoBoRC.exe REPLAY(or 1) 0000.txt -CH 000000ff -t 800:\n");
    showmsg("    Replay the single frame of servo positions in 0000.txt.\n");
    showmsg("    The frame is replayed on channels 0~7 by 800ms.\n");
	showmsg("    \n");
	showmsg("RoBoRC.exe CAPTURES(or 00) 0000.frm -CH 0000ffff:\n");
    showmsg("    Capture multiple frames of servo positions on channels 0~15.\n");
    showmsg("    The frames are saved to 0000.frm.\n");
	showmsg("    \n");
	showmsg("RoBoRC.exe REPLAYS(or 11) 0000.frm -CH 0000ffff -t 500:\n");
    showmsg("    Replay the multiple frames of servo positions in 0000.frm.\n");
    showmsg("    Each frame is replayed on channels 0~15 by 500ms.\n");

	showmsg("\n");
	showmsg("[press any key to continue...]\n"); keyboard_waitkey();
	showmsg("\n");

	showmsg("RoBoRC.exe CAPTURES_RT(or 000) 0000.frm -CH 0000ffff -t 300:\n");
    showmsg("    Capture in realtime multiple frames of\n");
    showmsg("    servo positions on channels 0~15 per 300ms.\n");
    showmsg("    The frames are saved to 0000.frm.\n");
	showmsg("    \n");
	showmsg("RoBoRC.exe REPLAYS_RT(or 111) 0000.frm -CH 0000ffff -t 100:\n");
    showmsg("    Replay in realtime the multiple frames of\n");
    showmsg("    servo positions in 0000.frm.\n");
    showmsg("    Each frame is replayed on channels 0~15 by 100ms.\n");
	showmsg("    \n");
	showmsg("RoBoRC.exe demo_directory -t 10000:\n");
    showmsg("    Load the Demo in demo_directory and\n");
    showmsg("    set the action idle time to 10000ms (which means that\n");
    showmsg("    the servo power will be turned off if the robot\n");
    showmsg("    idles over 10s after finishing an action).\n");

	showmsg("\n"); keyboard_waitkey();
}


#ifdef WINCE
int _tmain(int argc, _TCHAR* _argv[])
{
	char  argvbuf[50][100] = {'\0'};
	char* argv[50];

	if (argc > 50) argc = 50; //lazy code:p
	for (int _argc=0; _argc<argc; _argc++)
	{
		argv[_argc] = &(argvbuf[_argc][0]);
		wcstombs(argv[_argc], _argv[_argc], 100);
	}
#else
int main(int argc, char* argv[])
{
#endif

	#define MODE_CAPTURE  (0)
	#define MODE_CAPTURES (2)
	#define MODE_REPLAY   (1)
	#define MODE_REPLAYS  (3)
	#define MODE_DEMO     (100)
	int mode = MODE_CAPTURE;

	char* filename = "0000.txt";
	int	  frameno  = 0;
	unsigned long usedchannels = 0x00ffff80L; //default to use channels 7~23

/*
	#if defined(RB_MSVC_WIN32) || defined(RB_MSVC_WINCE)
		DWORD Error; //, priClass;

		//priClass = GetPriorityClass(GetCurrentProcess());
		if (!SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS)) //REALTIME_PRIORITY_CLASS or HIGH_PRIORITY_CLASS
		{
			Error = GetLastError();
			errmsg("Error: failed to enter HIGH_PRIORITY mode (%d)!\n", Error);
			goto End;
		}
	#endif
*/

	keyboard_init(KEYBOARD_STD);

	//parse user's arguments
	int i, argc_all = argc;
	for (i=1, argc=1; i<argc_all; i++) if (argv[i][0] != '-') argc++; else break;

	if (argc <= 1)
	{
		showhelp();
		goto End;
	}
	
	if ((_stricmp(argv[1], "0") == 0) || (_stricmp(argv[1], "CAPTURE") == 0))
	{
		mode = MODE_CAPTURE;
		if (argc > 2) filename = argv[2];
	}
	else
	if ((_stricmp(argv[1], "00") == 0) || (_stricmp(argv[1], "CAPTURES") == 0))
	{
		mode = MODE_CAPTURES;
		if (argc > 2) filename = argv[2];
		if (argc > 3) frameno = atoi(argv[3]);
	}
	else
	if ((_stricmp(argv[1], "000") == 0) || (_stricmp(argv[1], "CAPTURES_RT") == 0))
	{
		mode = MODE_CAPTURES;
		if (argc > 2) filename = argv[2];
		if (argc > 3) frameno = atoi(argv[3]);

		realtime = true;
	}
	else
	if ((_stricmp(argv[1], "1") == 0) || (_stricmp(argv[1], "REPLAY") == 0))
	{
		mode = MODE_REPLAY;
		if (argc > 2) filename = argv[2];
	}
	else
	if ((_stricmp(argv[1], "11") == 0) || (_stricmp(argv[1], "REPLAYS") == 0))
	{
		mode = MODE_REPLAYS;
		if (argc > 2) filename = argv[2];
		if (argc > 3) frameno = atoi(argv[3]);
	}
	else
	if ((_stricmp(argv[1], "111") == 0) || (_stricmp(argv[1], "REPLAYS_RT") == 0))
	{
		mode = MODE_REPLAYS;
		if (argc > 2) filename = argv[2];
		if (argc > 3) frameno = atoi(argv[3]);

		realtime = true;
	}
	else
	if (_stricmp(argv[1], "?") == 0)
	{
		showhelp();
		goto End;
	}
	else
	{
		mode = MODE_DEMO;
		filename   = argv[1];
		replaytime = 15000L;
	}

	for (i=argc; i<argc_all; i++)
	{
		if ((_stricmp(argv[i], "-OW") == 0) || (_stricmp(argv[i], "--overwrite") == 0))
		{
			overwrite = true;
			continue;
		}
		else
		if ((_stricmp(argv[i], "-RT") == 0) || (_stricmp(argv[i], "--realtime") == 0))
		{
			realtime = true;
			continue;
		}
		if ((_stricmp(argv[i], "-NM") == 0) || (_stricmp(argv[i], "--nomessage") == 0))
		{
			showmessage = false;
			continue;
		}

        if (i == argc_all-1) continue;
		if ((argv[i][0] != '-') || (argv[i+1][0] == '-')) continue;

		if ((_stricmp(argv[i], "-CH") == 0) || (_stricmp(argv[i], "--channels") == 0))
		{
			usedchannels = htol(argv[i+1]);
		}
		else
		if ((_stricmp(argv[i], "-t") == 0) || (_stricmp(argv[i], "--time") == 0))
		{
			replaytime = atol(argv[i+1]);
		}
		else
		if ((_stricmp(argv[i], "-SV") == 0) || (_stricmp(argv[i], "--servo") == 0))
		{
			if ((_stricmp(argv[i+1], "0") == 0) || (_stricmp(argv[i+1], "Generic") == 0))
                servo_idx = 0;
            else
			if ((_stricmp(argv[i+1], "1") == 0) || (_stricmp(argv[i+1], "KONDO") == 0))
                servo_idx = 1;
            else
			if ((_stricmp(argv[i+1], "2") == 0) || (_stricmp(argv[i+1], "HiTEC") == 0))
                servo_idx = 2;
		}
	}//end for (i=argc...


	//setup log file
	if (err_SetLogFile("roboard.log") == false)
		showmsg("WARNING: can't open file roboard.log for logging error messages!\n");

	switch (mode)
	{
		case MODE_CAPTURE:
			mode_captureframes(filename, -1, usedchannels);
			break;
		case MODE_CAPTURES:
			mode_captureframes(filename, frameno, usedchannels);
			break;
		case MODE_REPLAY:
			mode_replayframes(filename, -1, usedchannels);
			break;
		case MODE_REPLAYS:
			mode_replayframes(filename, frameno, usedchannels);
			break;
		case MODE_DEMO:
			mode_playdemo(filename, replaytime);
			break;
	}

	err_CloseLogFile();
End:
	keyboard_close();
	return 0;
}

