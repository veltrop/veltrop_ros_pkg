#ifndef __FILEIO_H
#define __FILEIO_H

#include "defines.h"

#if defined(RB_MSVC_WIN32)
	//#define USE_ZZIP
#endif

#ifdef USE_ZZIP
    #include <zzip/zzip.h>
    typedef ZZIP_FILE   FILEIO;
	typedef zzip_size_t FILEIO_SIZE_T;
	typedef zzip_off_t  FILEIO_OFF_T;
#else
    #include <stdio.h>
    typedef FILE   FILEIO;
	typedef size_t FILEIO_SIZE_T;
	typedef long   FILEIO_OFF_T;
#endif


#define INI_MAXLINESIZE     (1024)
#define INI_MAXELEMSIZE     (256)
extern char* INI_commentSymbols;
extern char* INI_separateSymbols;

typedef struct
{
    int  type;
    char itemname[INI_MAXELEMSIZE+1];
    char itemvalue[INI_MAXELEMSIZE+1];

} INI_ITEM_t;
//-- values for INI_ITEM_t.type
     #define  INI_GROUPTITLE   (0)
     #define  INI_GROUPITEM    (1)
     #define  INI_UNKNOWNITEM  (2)


#ifdef __cplusplus
extern "C" {
#endif

FILEIO* ini_FileOpen(char* filename);
void    ini_FileClose(FILEIO* fp);

bool ini_ReadNextItem(FILEIO* ini_fp, INI_ITEM_t* iniitem);
//-- if the above function return false, ERR_Type may be settled as the following number:
     #define ERROR_NOITEM            (ERR_NOERROR + 500)
     #define ERROR_EMPTYGROUPTITLE   (ERR_NOERROR + 501)
     #define ERROR_EMPTYITEMNAME     (ERR_NOERROR + 502)

bool ini_IsGroup(INI_ITEM_t* item, char* title);

bool ini_IsNumberedGroup(INI_ITEM_t* item, char* prefix);
//-- if the above function return false, ERR_Type may be settled as the following number:
     #define ERROR_UNKNOWNGROUP		(ERR_NOERROR + 510)
     #define ERROR_INVALIDGROUPNO	(ERR_NOERROR + 511)
long ini_ParseNumberedGroup(void);

bool ini_IsItem(INI_ITEM_t* item, char* name);

bool ini_IsTimeItem(INI_ITEM_t* item, char* name, char* postfix);
//-- if the above function return false, ERR_Type may be settled as the following number:
     #define ERROR_UNKNOWNITEM		(ERR_NOERROR + 520)
     #define ERROR_INVALIDTIME		(ERR_NOERROR + 521)
long ini_ParseTimeItem(void);

bool ini_IsNumberedItem(INI_ITEM_t* item, char* prefix);
//-- if the above function return false, ERR_Type may be settled as the following number:
//   #define ERROR_UNKNOWNITEM		(ERR_NOERROR + 520)
     #define ERROR_INVALIDITEMNO	(ERR_NOERROR + 531)
long ini_ParseNumberedItem(void);

bool ini_IsNumberedTimeItem(INI_ITEM_t* item, char* prefix, char* postfix);
//-- if the above function return false, ERR_Type may be settled as the following number:
//   #define ERROR_UNKNOWNITEM		(ERR_NOERROR + 520)
//   #define ERROR_INVALIDTIME		(ERR_NOERROR + 521)
//   #define ERROR_INVALIDITEMNO	(ERR_NOERROR + 531)
long ini_ParseNumberedTimeItem_Name(void);
long ini_ParseNumberedTimeItem_Time(void);


char* ini_RemoveSpace(char* str);              //may break str's content
long  ini_ParseTime(char* str, char* postfix); //may break str's content
bool  ini_IsNumber(char* str);


FILEIO*       fileio_FileOpen(char* filename, char* mode);
void          fileio_FileClose(FILEIO* fp);
FILEIO_SIZE_T fileio_Read(void* buf, FILEIO_SIZE_T size, FILEIO_SIZE_T count, FILEIO* fp);
char*         fileio_ReadLine(FILEIO* fp, char* buf, int maxcnt);
int           fileio_GetChar(FILEIO* fp);
int           fileio_Seek(FILEIO* fp, FILEIO_OFF_T offset, int origin);
FILEIO_OFF_T  fileio_GetPos(FILEIO* fp);
FILEIO_SIZE_T fileio_GetSize(FILEIO* fp);
bool          fileio_Exist(char* filename);
int           fileio_IsFileEnd(FILEIO* fp);

#ifdef __cplusplus
}
#endif

#endif

