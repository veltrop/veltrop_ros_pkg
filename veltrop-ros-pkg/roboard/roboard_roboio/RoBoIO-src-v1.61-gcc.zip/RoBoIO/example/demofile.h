#ifndef __DEMOFILE_H
#define __DEMOFILE_H

#include "defines.h"


#define CMD_MAXNAMELEN		(256)
typedef struct
{
    char     name[CMD_MAXNAMELEN+1];
    unsigned command;
    int      actno;

} CMD_t;


typedef struct _ACT_t
{
	int  type;
	long time;
	union
	{
		int            frameno;
		char*          filename;
		unsigned long* frame;

	} data;
	struct _ACT_t* next;

} ACT_t;
//-- values for ACT_t.type
     #define  ACT_PAUSE			(1)
     #define  ACT_PLAYFRAMENO	(2)
     #define  ACT_PLAYFRAME		(3)
     #define  ACT_PLAYSND		(4)


typedef struct {
	int     CMD_maxNum;
	int     CMD_num;
	CMD_t** cmdPool;
	int     initCMD;
	char    initCMDName[CMD_MAXNAMELEN+1];

	int     ACT_maxNum;
	ACT_t** actPool;

	int             FRM_maxNum;
	unsigned long** frmPool;

	int SND_maxNum; //unused at the moment

	unsigned long maxPWMDuty;
	unsigned long minPWMDuty;
	unsigned long PWMPeriod;

	unsigned long usedChannels;
	int channelMapping[32];

} DEF_t;


extern char* DEMOFILE_demoDirectory;


#ifdef __cplusplus
extern "C" {
#endif

char* demofile_GetPath(char* filepath);


//Functions for reading .cmd files:
void demofile_InitCMD(CMD_t* cmd[], int cmd_maxnum);
void demofile_FreeCMD(CMD_t* cmd[], int cmd_maxnum);

int  demofile_ReadCMD(char* filename, CMD_t* cmd[], int cmd_offset, int cmd_maxnum);
//-- if the above function return false, ERR_Type may be settled as the following number:
     #define ERROR_DEMOFILE_OPENFAIL (ERR_NOERROR + 600)
     #define ERROR_CMD_UNKNOWNITEM   (ERR_NOERROR + 611)
     #define ERROR_CMD_MISSNAME      (ERR_NOERROR + 613)
     #define ERROR_CMD_MISSCOMMAND   (ERR_NOERROR + 614)
     #define ERROR_CMD_MISSACTION    (ERR_NOERROR + 615)


//Functions for reading .act files:
extern long ACT_maxPauseTime;
extern long ACT_maxPlayTime;

void demofile_InitACT(ACT_t* act[], int act_maxnum);
void demofile_FreeACT(ACT_t* act[], int act_maxnum);

bool demofile_ReadACT(char* filename, ACT_t* act[], int act_maxnum);
//-- if the above function return false, ERR_Type may be settled as the following number:
//   #define ERROR_DEMOFILE_OPENFAIL	(ERR_NOERROR + 600)
     #define ERROR_ACT_UNKNOWNITEM		(ERR_NOERROR + 621)
     #define ERROR_ACT_INVALIDTIME		(ERR_NOERROR + 622)


//Functions for reading .frm files:
extern unsigned long FRM_minPWMDuty;
extern unsigned long FRM_maxPWMDuty;

void demofile_InitFRM(unsigned long* frm[], int frm_maxnum);
void demofile_FreeFRM(unsigned long* frm[], int frm_maxnum);

bool demofile_ReadSingleFRM(char* filename, unsigned long** frame);
bool demofile_ReadFRM(char* filename, unsigned long* frm[], int frm_maxnum);
//-- if the above function return false, ERR_Type may be settled as the following number:
//   #define ERROR_DEMOFILE_OPENFAIL	(ERR_NOERROR + 600)
     #define ERROR_FRM_UNKNOWNITEM		(ERR_NOERROR + 631)
     #define ERROR_FRM_INVALIDCHANNEL	(ERR_NOERROR + 635)


//Functions for reading .def files:
void demofile_FreeDEF(DEF_t* def);

bool demofile_ReadDEF(char* filename, DEF_t* def);
//-- if the above function return false, ERR_Type may be settled as the following number:
//   #define ERROR_DEMOFILE_OPENFAIL	(ERR_NOERROR + 600)
     #define ERROR_DEF_INVALIDCHANNEL	(ERR_NOERROR + 641)
     #define ERROR_DEF_UNKNOWNITEM		(ERR_NOERROR + 642)
     #define ERROR_DEF_NOFILES			(ERR_NOERROR + 643)

#ifdef __cplusplus
}
#endif

#endif

