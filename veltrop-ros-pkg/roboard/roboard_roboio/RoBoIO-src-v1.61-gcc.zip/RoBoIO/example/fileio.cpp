#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef USE_RBDLL
	#define  USE_COMMON
	#include <roboard_dll.h>
#else
	#define  USE_COMMON
	#include <roboard.h>
#endif
#include "fileio.h"

#if defined(RB_LINUX)
    #define _stricmp  strcasecmp
    #define _strnicmp strncasecmp
#elif defined(RB_BC_DOS) || defined(RB_DJGPP)
    #define _stricmp  stricmp
    #define _strnicmp strnicmp
#endif


/***********************  Functions for .ini Files  ***************************/
char* INI_commentSymbols  = ";";
char* INI_separateSymbols = "=";

static char  INI_parseBuf[1024];
static long  INI_parseValue, INI_parseValue2;

static char* ini_RemoveComment(char* str) {
	if (str != NULL) str[strcspn(str, INI_commentSymbols)] = '\0';
	return str;
}

char* ini_RemoveSpace(char* str) {
	int i;

	if (str == NULL) return str;

    i = (int)strlen(str);
    if (i == 0) return str; else i--; //ignore empty string

    //remove tail space chars
    while ((i >= 0) && (str[i] == ' ')) i--;
    str[i + 1] = '\0';

    //remove head space chars
    i = 0;
	while (str[i] == ' ') i++;
    return &(str[i]);

	/*
	//remove all space in the string
	int i = 0, j = 0;
	while ((str[i] = str[j++]) != '\0')
		if (str[i] != ' ') i++;
	*/
}

bool ini_IsNumber(char* str) {
	if (*str == '\0') return false;

	while (*str != '\0')
	{
        if ((*str < '0') || (*str > '9')) return false;
		str++;
	}
    return true;
}

long ini_ParseTime(char* str, char* postfix) {
	int i;

	if (str == NULL) return -1; else i = (int)strlen(str);

	//remove the postfix if it exists; strlen(postfix) must = 2 (lazy code:p)
	if ((i >= 2) && (postfix != NULL)) //&&
	if ((str[i-2] == postfix[0]) && (str[i-1] == postfix[1]))
	{
		str[i-2] = '\0';
		str = ini_RemoveSpace(str);
		i = (int)strlen(str);
	}

	if (i == 0)	return -1L;
	if (ini_IsNumber(str) == false) return -1L;

	return atol(str);
}


FILEIO* ini_FileOpen(char* filename) {
	return fileio_FileOpen(filename, "r");
}

void ini_FileClose(FILEIO* fp) {
	fileio_FileClose(fp);
}


bool ini_ReadNextItem(FILEIO* fp, INI_ITEM_t* iniitem) {
    char buf[INI_MAXLINESIZE+1], *str = "";
    int  i;

    //read a line
    while (!fileio_IsFileEnd(fp))
    {
		str = fileio_ReadLine(fp, buf, INI_MAXLINESIZE);
        str = ini_RemoveSpace(ini_RemoveComment(str));
		if (strlen(str) != 0) break;
    }

    //parse the line
    if (strlen(str) == 0)
    {
        err_SetMsg(ERROR_NOITEM, "ini_ReadNextItem(): no next item to read");
        return false;
    }
    else
	if ((str[0] == '[') && (str[strlen(str)-1] == ']'))
    {
        str[strlen(str)-1] = '\0';
        strcpy(iniitem->itemname, ini_RemoveSpace(&str[1]));
		if (strlen(iniitem->itemname) == 0)
        {
            err_SetMsg(ERROR_EMPTYGROUPTITLE, "ini_ReadNextItem(): empty group title");
            return false;
        }

        iniitem->type = INI_GROUPTITLE;
        return true;
    }
    else
	if ((i = (int)strcspn(str, INI_separateSymbols)) != (int)strlen(str))
    {
        str[i] = '\0';
        strcpy(iniitem->itemname,  ini_RemoveSpace(str));
        strcpy(iniitem->itemvalue, ini_RemoveSpace(&str[i+1]));
        if (strlen(iniitem->itemname) == 0)
        {
			err_SetMsg(ERROR_EMPTYITEMNAME, "ini_ReadNextItem(): item with empty name");
            return false;                
        }

        iniitem->type = INI_GROUPITEM;
        return true;
    }
    else
    {
        strcpy(iniitem->itemname, str);
        iniitem->type = INI_UNKNOWNITEM;
        return true;
    } //end if (strlen...
}


//====================   Parsing Functions  ====================>:
bool ini_IsGroup(INI_ITEM_t* item, char* title) {
	if (_stricmp(item->itemname, title) == 0) return true;
	return false;
}

bool ini_IsNumberedGroup(INI_ITEM_t* item, char* prefix) {
	char* str1 = strcpy(INI_parseBuf, item->itemname);

	if ((strlen(str1) > strlen(prefix)) && (_strnicmp(str1, prefix, strlen(prefix)) == 0))
    {
		str1[strcspn(str1, ",")] = '\0';
		str1 = ini_RemoveSpace(&str1[strlen(prefix)]);

		if (ini_IsNumber(str1) == true)
		{
			INI_parseValue = atol(str1);
			return true;
		}
		else
		{
			err_SetMsg(ERROR_INVALIDGROUPNO, "group title [%s] has a invalid number", INI_parseBuf);
			return false;
		}
    }

	err_SetMsg(ERROR_UNKNOWNGROUP, "group title [%s] is unknown", INI_parseBuf);
	return false;
}

//can only be called just after ini_IsGroupTitle2(...)
long ini_ParseNumberedGroup(void) {
	return INI_parseValue;
}

bool ini_IsItem(INI_ITEM_t* item, char* name) {
	if (_stricmp(item->itemname, name) == 0) return true;
	return false;
}

bool ini_IsTimeItem(INI_ITEM_t* item, char* name, char* postfix) {
	char* str;

	if (ini_IsItem(item, name) == false)
	{
		err_SetMsg(ERROR_UNKNOWNITEM, "item %s = %s is unknown", item->itemname, item->itemvalue);
		return false;
	}

	str = strcpy(INI_parseBuf, item->itemvalue);
	if ((INI_parseValue = ini_ParseTime(str, postfix)) == -1)
	{
		err_SetMsg(ERROR_INVALIDTIME, "item %s = %s is an invalid assignment", item->itemname, item->itemvalue);
		return false;
	}
	return true;
}

//can only be called just after ini_IsTimeItem(...)
long ini_ParseTimeItem(void) {
	return INI_parseValue;
}

bool ini_IsNumberedItem(INI_ITEM_t* item, char* prefix) {
	char* str;

	if ((strlen(item->itemname) > strlen(prefix)) && (_strnicmp(item->itemname, prefix, strlen(prefix)) == 0))
    {
		str = strcpy(INI_parseBuf, item->itemname);
		str = ini_RemoveSpace(&str[strlen(prefix)]);

		if (ini_IsNumber(str) == true)
		{
			INI_parseValue = atol(str);
			return true;
		}
		else
		{
			err_SetMsg(ERROR_INVALIDITEMNO, "numbered item %s = %s has a invalid number", item->itemname, item->itemvalue);
			return false;
		}
	}

	err_SetMsg(ERROR_UNKNOWNITEM, "item %s = %s is unknown", item->itemname, item->itemvalue);
	return false;
}

//can only be called just after ini_IsNumberedItem(...)
long ini_ParseNumberedItem(void) {
	return INI_parseValue;
}

bool ini_IsNumberedTimeItem(INI_ITEM_t* item, char* prefix, char* postfix) {
	char* str;

	if (ini_IsNumberedItem(item, prefix) == false) return false;

	INI_parseValue2 = INI_parseValue;

	str = strcpy(INI_parseBuf, item->itemvalue);
	if ((INI_parseValue = ini_ParseTime(str, postfix)) == -1)
	{
		err_SetMsg(ERROR_INVALIDTIME, "item %s = %s is an invalid assignment", item->itemname, item->itemvalue);
		return false;
	}
	return true;
}

//can only be called just after ini_IsNumberedItem(...)
long ini_ParseNumberedTimeItem_Name(void) {
	return INI_parseValue2;
}

//can only be called just after ini_IsNumberedItem(...)
long ini_ParseNumberedTimeItem_Time(void) {
	return INI_parseValue;
}
/*---------------------  end of Func. for .ini Files  ------------------------*/



FILEIO* fileio_FileOpen(char* filename, char* mode) {
    #ifdef USE_ZZIP
		char str[256];

		strcpy(str, mode);
        return zzip_fopen(filename, strcat(str, "i")); //mode | ZZIP_CASELESS
    #else
        return fopen(filename, mode);
    #endif
}

void fileio_FileClose(FILEIO* fp) {
    #ifdef USE_ZZIP
        zzip_fclose(fp);
    #else
        fclose(fp);
    #endif
}

FILEIO_SIZE_T fileio_Read(void* buf, FILEIO_SIZE_T size, FILEIO_SIZE_T count, FILEIO* fp) {
    #ifdef USE_ZZIP
        return zzip_fread(buf, size, count, fp);
    #else
        return fread(buf, size, count, fp);
    #endif
}

char* fileio_ReadLine(FILEIO* fp, char* buf, int maxcnt) {
    int i = 0, c;
    
    for (i=0; i<maxcnt; i++)
    {
        if ((c=fileio_GetChar(fp)) == EOF) break;
        if ((c == '\r') || (c == '\n')) break;
        buf[i] = c;
    }
    buf[i] = '\0';
    
    //clear remaining chars in the current line
    if (i == maxcnt)
    {
        while((c=fileio_GetChar(fp)) != EOF)
            if ((c == '\r') || (c == '\n')) break;
    }
    
    return buf;
}

/*
#ifdef USE_ZZIP
	static char INI_ReadBuf[256];
	static int  INI_CurChar = -1;
#endif
int ini_GetChar(INIFILE* fp) {
    #ifdef USE_ZZIP

        int i;
        
        if ((INI_CurChar == -1) || (INI_ReadBuf[INI_CurChar] == '\0'))
        {
            i = (int)zzip_fread(INI_ReadBuf, sizeof(INI_ReadBuf[0]), 255, fp);
            if (i <= 0) return EOF;

            INI_ReadBuf[i] = '\0';
            INI_CurChar = 0;
        }

        return INI_ReadBuf[INI_CurChar++];
    #else
        return fgetc(fp);
    #endif
}

int ini_IsFileEnd(INIFILE* fp) {
    #ifdef USE_ZZIP
		long cur_offset, end_offset;

		if ((INI_CurChar == -1) || (INI_ReadBuf[INI_CurChar] == '\0'))
		{
			cur_offset = zzip_tell(fp);
			zzip_seek(fp, 0L, SEEK_END);
			end_offset = zzip_tell(fp);

			if (cur_offset >= end_offset) return 1;
			zzip_seek(fp, cur_offset, SEEK_SET);
		}
		return 0;
	#else
        return feof(fp);
    #endif
}
*/

int fileio_GetChar(FILEIO* fp) {
    #ifdef USE_ZZIP
		char buf[1];
		int  i = (int)zzip_fread(buf, sizeof(buf[0]), 1, fp);

		if (i <= 0) return EOF; else return (int)buf[0];
    #else
        return fgetc(fp);
    #endif
}

bool fileio_Exist(char* filename) {
	FILEIO* fp;

	if ((fp = fileio_FileOpen(filename, "r")) == NULL) return false;

	fileio_FileClose(fp);
    return true;
}

int fileio_IsFileEnd(FILEIO* fp) {
    #ifdef USE_ZZIP
		FILEIO_OFF_T cur_offset, end_offset;

		cur_offset = zzip_tell(fp);
		zzip_seek(fp, 0L, SEEK_END);
		end_offset = zzip_tell(fp);

		if (cur_offset >= end_offset) return 1;
		zzip_seek(fp, cur_offset, SEEK_SET);

		return 0;
	#else
        return feof(fp);
    #endif
}

FILEIO_SIZE_T fileio_GetSize(FILEIO* fp) {
	FILEIO_OFF_T cur_offset, end_offset;

	#ifdef USE_ZZIP
		cur_offset = zzip_tell(fp);
		zzip_seek(fp, 0L, SEEK_END);
		end_offset = zzip_tell(fp);
		zzip_seek(fp, cur_offset, SEEK_SET);
	#else
		cur_offset = ftell(fp);
		fseek(fp, 0L, SEEK_END);
		end_offset = ftell(fp);
		fseek(fp, cur_offset, SEEK_SET);
    #endif

	return end_offset;
}

int fileio_Seek(FILEIO* fp, FILEIO_OFF_T offset, int origin) {
	#ifdef USE_ZZIP
		if (zzip_seek(fp, offset, origin) >= 0L) return 0;
		return -1;
	#else
		return fseek(fp, offset, origin);
    #endif
}

FILEIO_OFF_T  fileio_GetPos(FILEIO* fp) {
	#ifdef USE_ZZIP
		return zzip_tell(fp);
	#else
		return ftell(fp);
    #endif
}
