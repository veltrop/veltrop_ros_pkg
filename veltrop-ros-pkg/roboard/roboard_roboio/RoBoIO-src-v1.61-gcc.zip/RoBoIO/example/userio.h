#ifndef __USERIO_H
#define __USERIO_H

#include "defines.h"


#ifdef __cplusplus
extern "C" {
#endif

//MESSAGE
bool msg_SetLogFile(char* logfile);
void msg_CloseLogFile(void);

void showmsg(char* fmt, ...);


//KEYBOARD:
void keyboard_init(int type);
    #define KEYBOARD_STD    (1)
    #define KEYBOARD_ADV    (2)

void keyboard_close(void);

unsigned keyboard_getkey(void);
unsigned keyboard_waitkey(void);
    #define KBENTER         (0x000d)
    #define KBTAB           (0x0009)
    #define KBESC           (0x001b)
    #define KBBACKSPACE     (0x0008)
    #define KBSPACE         (0x0020)

    #define KBLEFT          (0x0025)
    #define KBRIGHT         (0x0027)
    #define KBUP            (0x0026)
    #define KBDOWN          (0x0028)

    #define KBHOME          (0x0024)
    #define KBEND           (0x0023)
    #define KBPGUP          (0x0021)
    #define KBPGDN          (0x0022)

    #define KBINS           (0x002d)
    #define KBDEL           (0x002e)

    #define KBF1            (0x0070)
    #define KBF2            (0x0071)
    #define KBF3            (0x0072)
    #define KBF4            (0x0073)
    #define KBF5            (0x0074)
    #define KBF6            (0x0075)
    #define KBF7            (0x0076)
    #define KBF8            (0x0077)
    #define KBF9            (0x0078)
    #define KBF10           (0x0079)
    #define KBF11           (0x007a)
    #define KBF12           (0x007b)

    #define KBSHIFT         (0x0010)
    #define KBLSHIFT        (0x00a0)
    #define KBRSHIFT        (0x00a1)
    #define KBCTRL          (0x0011)
    #define KBLCTRL         (0x00a2)
    #define KBRCTRL         (0x00a3)
    #define KBALT           (0x0012)
    #define KBLALT          (0x00a4)
    #define KBRALT          (0x00a5)

#ifdef __cplusplus
}
#endif
#endif

