#include <string.h>

#ifdef USE_RBDLL
	#define  USE_COMMON
	#include <roboard_dll.h>
#else
	#define  USE_COMMON
	#include <roboard.h>
#endif
#include "userio.h"
#include "fileio.h"
#include "demofile.h"

#if defined(RB_LINUX)
    #define _stricmp  strcasecmp
    #define _strnicmp strncasecmp
#elif defined(RB_BC_DOS) || defined(RB_DJGPP)
    #define _stricmp  stricmp
    #define _strnicmp strnicmp
#endif


/*********************  Read Functions of CMD Files  *********************/
static CMD_t* cmd_InitializeCommand(CMD_t* cmd) {
	if (cmd == NULL) cmd = (CMD_t*)mem_alloc(sizeof(CMD_t));

	cmd->name[0] = '\0';
    cmd->command = 0xffff;
    cmd->actno   = -1;
	return cmd;
}

static bool cmd_VerifyCommand(CMD_t* cmd) {
    if (strlen(cmd->name) == 0)
    {
        err_SetMsg(ERROR_CMD_MISSNAME, "found a [Command] group missing \"name\" item");
        return false;
    }
    else
	if (cmd->command == 0xffff)
    {
        err_SetMsg(ERROR_CMD_MISSCOMMAND, "found [Command] group missing \"command\" item");
        return false;
    }
    else
	if (cmd->actno == -1)
    {
        err_SetMsg(ERROR_CMD_MISSACTION, "found [Command] group missing \"action\" item");
        return false;
    }

    return true;
}


static struct {char* keyname; unsigned keyvalue;} CMD_specialKey[] =
	{
        {"F1",  KBF1},
        {"F2",  KBF2},
        {"F3",  KBF3},
        {"F4",  KBF4},
        {"F5",  KBF5},
        {"F6",  KBF6},
        {"F7",  KBF7},
        {"F8",  KBF8},
        {"F9",  KBF9},
        {"F10", KBF10},
        {"F11", KBF11},
        {"F12", KBF12},
        {"ENTER", KBENTER},
        //{"SPACE", KBSPACE},
        {"UP",    KBUP},
        {"DOWN",  KBDOWN},
        {"LEFT",  KBLEFT},
        {"RIGHT", KBRIGHT},
        {"PGUP",  KBPGUP},
        {"PGDN",  KBPGDN}
	};
#define NUM_SPECIALKEY  (sizeof(CMD_specialKey)/sizeof(CMD_specialKey[0]))

static bool cmd_ParseItem_Command(CMD_t* cmd, INI_ITEM_t* item) {
    int i;

    if ((ini_IsItem(item, "name") == true) && (strlen(item->itemvalue) != 0))
    {
		if (strlen(item->itemvalue) > CMD_MAXNAMELEN)
			errmsg("WARNING: item %s must has value <= %d chars!\n", item->itemname, CMD_MAXNAMELEN);

        strncpy(cmd->name, item->itemvalue, CMD_MAXNAMELEN);
        cmd->name[CMD_MAXNAMELEN] = '\0';
    } //end if (..."name"...
    else
	if ((ini_IsItem(item, "command") == true) && (strlen(item->itemvalue) != 0))
    {
		if (strlen(item->itemvalue) == 1)
        {
            if ((item->itemvalue[0] >= 'A') && (item->itemvalue[0] <= 'Z'))
                cmd->command = item->itemvalue[0];
            else
            if ((item->itemvalue[0] >= 'a') && (item->itemvalue[0] <= 'z'))
                cmd->command = cmd->command - 'a' + 'A';
            else
				errmsg("WARNING: item %s = %s indicates a supported key!\n", item->itemname, item->itemvalue);
        }
        else
        {
            for (i=0; i<(int)NUM_SPECIALKEY; i++)
                if (_stricmp(item->itemvalue, CMD_specialKey[i].keyname) == 0)
                {
                    cmd->command = CMD_specialKey[i].keyvalue;
                    break;
                }

			if (i == NUM_SPECIALKEY)
				errmsg("WARNING: item %s = %s indicates an unknown key!\n", item->itemname, item->itemvalue);
        }
    } //end if (..."command"...
    else
	if (ini_IsTimeItem(item, "action", NULL) == true)
    {
		cmd->actno = ini_ParseTimeItem();
    } //end if (..."action"...
	else
	{
		err_SetMsg(ERROR_CMD_UNKNOWNITEM, "unknown item %s = %s appears in [Command] group", item->itemname, item->itemvalue);
		return false;
	}
    return true;
}


int demofile_ReadCMD(char* filename, CMD_t* cmd[], int cmd_offset, int cmd_maxnum) {
    FILEIO*    fp;
    INI_ITEM_t item;
	int  cmd_cur = cmd_offset - 1;

    #define CMDGROUP_NONE      (0)
    #define CMDGROUP_COMMAND   (1)
    #define CMDGROUP_UNKNOWN   (2)
    int gflag = CMDGROUP_NONE;

    if ((fp = ini_FileOpen(demofile_GetPath(filename))) == NULL)
    {		
		err_SetMsg(ERROR_DEMOFILE_OPENFAIL, "cannot open the command file: %s", filename);
        return -1;
    }

    while (ini_ReadNextItem(fp, &item) == true)
    {
        switch(item.type)
        {
            case INI_GROUPTITLE:
                gflag = CMDGROUP_UNKNOWN;

				if (ini_IsGroup(&item, "Command") == true)
                {
                    if (cmd_cur >= cmd_offset) //&&
                    if (cmd_VerifyCommand(cmd[cmd_cur]) == false) goto END_READCMD_FAIL;

                    cmd_cur = cmd_cur + 1;
                    if (cmd_cur >= cmd_maxnum) goto END_READCMD;

                    cmd[cmd_cur] = cmd_InitializeCommand(cmd[cmd_cur]);
                    gflag = CMDGROUP_COMMAND;
                }
                else
					errmsg("WARNING: unknown group [%s]!\n", item.itemname);
                break;
            case INI_GROUPITEM:
                if (gflag == CMDGROUP_COMMAND)
                {
                    if (cmd_ParseItem_Command(cmd[cmd_cur], &item) == false) goto END_READCMD_FAIL;
                }
                else
				if (gflag != CMDGROUP_UNKNOWN)
                {
                    errmsg("WARNING: item %s = %s not in a group!\n", item.itemname, item.itemvalue);
                }
                break;
            case INI_UNKNOWNITEM:
				if (gflag == CMDGROUP_NONE)
                {
                    errmsg("WARNING: item %s not in a group!\n", item.itemname);
					break;
                }

				err_SetMsg(ERROR_CMD_UNKNOWNITEM, "unknown item %s", item.itemname);
				goto END_READCMD_FAIL;
        } //end switch(item...
    } //end while(ini_...


END_READCMD:
    ini_FileClose(fp);

    if (cmd_cur < cmd_offset)  return cmd_offset;
	if (cmd_cur >= cmd_maxnum) return cmd_maxnum;
	if (cmd_VerifyCommand(cmd[cmd_cur]) == false) return -1; else return cmd_cur+1;

END_READCMD_FAIL:
    ini_FileClose(fp);
	return -1;
}

void demofile_InitCMD(CMD_t* cmd[], int cmd_maxnum) {
	int i;

	for (i=0; i<cmd_maxnum; i++) cmd[i] = NULL;
}

void demofile_FreeCMD(CMD_t* cmd[], int cmd_maxnum) {
	int i;

	for (i=0; i<cmd_maxnum; i++)
		if (cmd[i] != NULL)
		{
			free(cmd[i]);
			cmd[i] = NULL;
		}
}
/*------------------  end Read Functions of CMD Files  ------------------*/



/*********************  Read Functions of FRM Files  *********************/
unsigned long FRM_minPWMDuty = 500L;  //in us
unsigned long FRM_maxPWMDuty = 2800L; //in us

static bool frm_ParseItem_Frame(unsigned long* frm, INI_ITEM_t* item) {
	long t, t2;

	if (ini_IsNumberedTimeItem(item, "Channel", "us") == false) //&&
	if (ini_IsNumberedTimeItem(item, "CH", "us") == false)
	{
		err_SetMsg(ERROR_FRM_UNKNOWNITEM, "unknown item %s = %s appears in [Frame] group", item->itemname, item->itemvalue);
		return false;
	}

	t = ini_ParseNumberedTimeItem_Name();
	if ((t < 0L) || (t > 31L))
	{
		err_SetMsg(ERROR_FRM_INVALIDCHANNEL, "item %s = %s indicates an invalid channel", item->itemname, item->itemvalue);
		return false;
	}

	t2 = ini_ParseNumberedTimeItem_Time();
	if ((t2 != 0L) && (((unsigned long)t2 < FRM_minPWMDuty) || ((unsigned long)t2 > FRM_maxPWMDuty)))
	{
		errmsg("WARNING: PWM duty cycle in item %s = %s is out of range!\n", item->itemname, item->itemvalue);
		return true;
	}

	if (frm[t] != 0L)
		errmsg("WARNING: Repeated channel no. in item %s = %s!\n", item->itemname, item->itemvalue);
	else
		frm[t] = t2;

	return true;
}


bool demofile_ReadSingleFRM(char* filename, unsigned long** frame) {
    FILEIO*    fp;
    INI_ITEM_t item;
	int i;

    if ((fp = ini_FileOpen(demofile_GetPath(filename))) == NULL)
    {
        err_SetMsg(ERROR_DEMOFILE_OPENFAIL, "cannot open the frame file: %s", filename);
        return false;
    }

	*frame = (unsigned long*)mem_alloc(32 * sizeof(unsigned long));
	for (i=0; i<32; i++) (*frame)[i] = 0L;

    while (ini_ReadNextItem(fp, &item) == true)
    {
		switch(item.type)
        {
            case INI_GROUPITEM:
				if (frm_ParseItem_Frame(*frame, &item) == false) goto END_READSFRM_FAIL;
                break;
            case INI_UNKNOWNITEM:
				err_SetMsg(ERROR_FRM_UNKNOWNITEM, "unknown item %s", item.itemname);
				goto END_READSFRM_FAIL;
        } //end switch(item...
    } //end while(ini_...

    ini_FileClose(fp);
	return true;

END_READSFRM_FAIL:
	free(*frame);
	ini_FileClose(fp);
	return false;
}


bool demofile_ReadFRM(char* filename, unsigned long* frm[], int frm_maxnum) {
    FILEIO*    fp;
    INI_ITEM_t item;
	int frm_cur, i;

    #define FRMGROUP_NONE      (0)
    #define FRMGROUP_FRAME     (1)
    #define FRMGROUP_UNKNOWN   (2)
    int gflag = FRMGROUP_NONE;

    if ((fp = ini_FileOpen(demofile_GetPath(filename))) == NULL)
    {
        err_SetMsg(ERROR_DEMOFILE_OPENFAIL, "cannot open the frame file: %s", filename);
        return false;
    }

    while (ini_ReadNextItem(fp, &item) == true)
    {
		switch(item.type)
        {
            case INI_GROUPTITLE:
                gflag = FRMGROUP_UNKNOWN;

				if (ini_IsNumberedGroup(&item, "Frame ") == true)
				{
					frm_cur = ini_ParseNumberedGroup();
					if (frm_cur >= frm_maxnum)
						errmsg("WARNING: Frame no. of group [%s] is too large!\n", item.itemname);
					else
					if (frm[frm_cur] != NULL)
						errmsg("WARNING: Repeated frame no. in group [%s]!\n", item.itemname);
					else
					{
						gflag = FRMGROUP_FRAME;
						frm[frm_cur] = (unsigned long*)mem_alloc(32 * sizeof(unsigned long));
						for (i=0; i<32; i++) frm[frm_cur][i] = 0L;
					}
				}
				else
					errmsg("WARNING: unknown group [%s]!\n", item.itemname);
                break;
            case INI_GROUPITEM:
				if (gflag == FRMGROUP_FRAME)
                {
					if (frm_ParseItem_Frame(frm[frm_cur], &item) == false) goto END_READFRM_FAIL;
                }
                else
				if (gflag != FRMGROUP_UNKNOWN)
                {
                    errmsg("WARNING: item %s = %s not in a group!\n", item.itemname, item.itemvalue);
                }
                break;
            case INI_UNKNOWNITEM:
				if (gflag == FRMGROUP_NONE)
                {
                    errmsg("WARNING: item %s not in a group!\n", item.itemname);
					break;
                }

				err_SetMsg(ERROR_FRM_UNKNOWNITEM, "unknown item %s", item.itemname);
				goto END_READFRM_FAIL;
        } //end switch(item...
    } //end while(ini_...

    ini_FileClose(fp);
	return true;

END_READFRM_FAIL:
    ini_FileClose(fp);
	return false;
}


void demofile_InitFRM(unsigned long* frm[], int frm_maxnum) {
	int i;

	for (i=0; i<frm_maxnum; i++) frm[i] = NULL;
}

void demofile_FreeFRM(unsigned long* frm[], int frm_maxnum) {
	int i;

	for (i=0; i<frm_maxnum; i++)
		if (frm[i] != NULL) free(frm[i]);
}
/*------------------  end Read Functions of FRM Files  ------------------*/



/*********************  Read Functions of ACT Files  *********************/
long ACT_maxPauseTime = 999999L; //in ms
long ACT_maxPlayTime  = 999999L; //in ms

static ACT_t* act_InsertNewAction(ACT_t* actitem) {
	if (actitem == NULL)
		actitem = (ACT_t*)mem_alloc(sizeof(ACT_t));
	else
	{
		actitem->next = (ACT_t*)mem_alloc(sizeof(ACT_t));
		actitem = actitem->next;
	}

	actitem->next = NULL;
	return actitem;
}

static void act_FreeAction(ACT_t* actitem) {
	if (actitem == NULL) return;

	act_FreeAction(actitem->next);
	switch(actitem->type)
	{
		case ACT_PLAYFRAME:
			free(actitem->data.frame);
			break;
		case ACT_PLAYSND:
			free(actitem->data.filename);
			break;
	}

	free(actitem);
}


static bool act_ParseItem_Action(ACT_t** actitem_p, INI_ITEM_t* item) {
	ACT_t* actitem = *actitem_p;

	int   i;
	long  t;
    char* str;
	unsigned long* frame;

	char tmp_ParseBuf[INI_MAXELEMSIZE+1];

	//if ((ini_IsTimeItem(item, "Pause", "ms") == true) || (ini_IsTimeItem(item, "Delay", "ms") == true))
	if ((ini_IsItem(item, "Pause") == true) || (ini_IsItem(item, "Delay") == true))
	{
		if (ini_IsTimeItem(item, "Pause", "ms") == false) //&&
		if (ini_IsTimeItem(item, "Delay", "ms") == false)
			goto NON_PAUSEITEM; //ugly code,  but I'm intentional:p

		t = ini_ParseTimeItem();
		if ((t == 0L) || (t > ACT_maxPauseTime))
		{
			err_SetMsg(ERROR_ACT_INVALIDTIME, "item %s = %s indicates a zero or too large pause time", item->itemname, item->itemvalue);
			return false;
		}

		actitem = act_InsertNewAction(actitem);
		actitem->type = ACT_PAUSE;
		actitem->time = t;
	}//end if (..."Pause"...
	else
NON_PAUSEITEM:
	if (ini_IsItem(item, "MoveToFrame") == true)
	{
		strcpy(tmp_ParseBuf, item->itemvalue);

		i = (int)strcspn(tmp_ParseBuf, ",");
		if (i != (int)strlen(tmp_ParseBuf))
		{
			tmp_ParseBuf[i] = '\0';
			str = ini_RemoveSpace(&(tmp_ParseBuf[i+1]));
		}
		else
			str = "";

		t = ini_ParseTime(str, "ms");
		if ((t <= 0L) || (t > ACT_maxPlayTime))
		{
			err_SetMsg(ERROR_ACT_INVALIDTIME, "item %s = %s indicates an invalid time", item->itemname, item->itemvalue);
			return false;
		}

		str = ini_RemoveSpace(tmp_ParseBuf);
		if (ini_IsNumber(str) == true)
		{
			actitem = act_InsertNewAction(actitem);
			actitem->type = ACT_PLAYFRAMENO;
			actitem->time = t;
			actitem->data.frameno = atol(str);
		}
		else
		{
			if (demofile_ReadSingleFRM(str, &frame) == false) return false;
			actitem = act_InsertNewAction(actitem);
			actitem->type = ACT_PLAYFRAME;
			actitem->time = t;
			actitem->data.frame = frame;
		}
	}//end if (..."MoveToFrame"...
	else
	if (ini_IsItem(item, "PlaySnd") == true)
	{
		str = demofile_GetPath(item->itemvalue);
		if (fileio_Exist(str) == true)
		{
			actitem = act_InsertNewAction(actitem);
			actitem->type = ACT_PLAYSND;
			actitem->data.filename = (char*)mem_alloc((strlen(str)+1) * sizeof(char));
			strcpy(actitem->data.filename, str);
		}
		else
			errmsg("WARNING: item %s = %s indicates a nonexisting sound file!\n", item->itemname, item->itemvalue);
	}//end if (..."PlaySnd"...
	else
	{
		//try to take the unknown item as a frame setting
		t = ini_ParseTime(item->itemvalue, "ms");
		if ((t > 0L) && (t <= ACT_maxPlayTime)) //&&
		if (demofile_ReadSingleFRM(item->itemname, &frame) == true)
		{
			actitem = act_InsertNewAction(actitem);
			actitem->type = ACT_PLAYFRAME;
			actitem->time = t;
			actitem->data.frame = frame;
			goto END_READACTITEM;
		}

		err_SetMsg(ERROR_ACT_UNKNOWNITEM, "unknown item %s = %s appears in [Action] group", item->itemname, item->itemvalue);
		return false;
	}//end if (...unknown item...

END_READACTITEM:
	*actitem_p = actitem;
	return true;
}


bool demofile_ReadACT(char* filename, ACT_t* act[], int act_maxnum) {
    FILEIO*    fp;
    INI_ITEM_t item;

	int    act_cur;
	ACT_t* actitem_cur;

    #define ACTGROUP_NONE      (0)
    #define ACTGROUP_ACTION    (1)
    #define ACTGROUP_UNKNOWN   (2)
    int gflag = ACTGROUP_NONE;

    if ((fp = ini_FileOpen(demofile_GetPath(filename))) == NULL)
    {
        err_SetMsg(ERROR_DEMOFILE_OPENFAIL, "cannot open the action file: %s", filename);
        return false;
    }

    while (ini_ReadNextItem(fp, &item) == true)
    {
		switch(item.type)
        {
            case INI_GROUPTITLE:
				gflag = ACTGROUP_UNKNOWN;

				if (ini_IsNumberedGroup(&item, "Action ") == true)
				{
					act_cur = ini_ParseNumberedGroup();
					if (act_cur >= act_maxnum)
						errmsg("WARNING: Action no. of group [%s] is too large!\n", item.itemname);
					else
					if (act[act_cur] != NULL)
						errmsg("WARNING: Repeated action no. in group [%s]!\n", item.itemname);
					else
					{
						gflag = ACTGROUP_ACTION;
						actitem_cur = NULL;
					}
				}
				else
					errmsg("WARNING: unknown group [%s]!\n", item.itemname);
                break;
            case INI_GROUPITEM:
                if (gflag == ACTGROUP_ACTION)
                {
					if (act_ParseItem_Action(&actitem_cur, &item) == false) goto END_READACT_FAIL;
					if (act[act_cur] == NULL) act[act_cur] = actitem_cur;
                }
                else
				if (gflag != ACTGROUP_UNKNOWN)
                {
                    errmsg("WARNING: item %s = %s not in a group!\n", item.itemname, item.itemvalue);
                }
                break;
            case INI_UNKNOWNITEM:
				if (gflag == ACTGROUP_NONE)
                {
                    errmsg("WARNING: item %s not in a group!\n", item.itemname);
					break;
                }

				err_SetMsg(ERROR_ACT_UNKNOWNITEM, "unknown item %s", item.itemname);
				goto END_READACT_FAIL;
        } //end switch(item...
    } //end while(ini_...

    ini_FileClose(fp);
	return true;

END_READACT_FAIL:
    ini_FileClose(fp);
	return false;
}


void demofile_InitACT(ACT_t* act[], int act_maxnum) {
	int i;

	for (i=0; i<act_maxnum; i++) act[i] = NULL;
}

void demofile_FreeACT(ACT_t* act[], int act_maxnum) {
	int i;

	for (i=0; i<act_maxnum; i++)
	{
		act_FreeAction(act[i]);
		act[i] = NULL;
	}
}
/*------------------  end Read Functions of ACT Files  ------------------*/



static bool def_ParseItem_Channels(DEF_t* def, INI_ITEM_t* item) {
	long t, t2;

	if (ini_IsNumberedTimeItem(item, "MapChannel", NULL) == true)
	{
		t  = ini_ParseNumberedTimeItem_Name();
		t2 = ini_ParseNumberedTimeItem_Time();

		if ((t < 0L) || (t > 31L) || (t2 < 0L) || (t2 > 31L))
		{
			err_SetMsg(ERROR_DEF_INVALIDCHANNEL, "item %s = %s indicates an invalid channel", item->itemname, item->itemvalue);
			return false;
		}

		def->channelMapping[t] = t2;
	}
	else
	{
		if (ini_IsNumberedItem(item, "Channel") == false) //&&
		if (ini_IsNumberedItem(item, "CH") == false)
		{
			err_SetMsg(ERROR_DEF_UNKNOWNITEM, "unknown item %s = %s appears in [Channels] group", item->itemname, item->itemvalue);
			return false;
		}

		t = ini_ParseNumberedItem();
		if ((t < 0L) || (t > 31L))
		{
			err_SetMsg(ERROR_DEF_INVALIDCHANNEL, "item %s = %s indicates an invalid channel", item->itemname, item->itemvalue);
			return false;
		}

		if (_stricmp(item->itemvalue, "ON") == 0)
			def->usedChannels = def->usedChannels | (1L << t);
		else
		if (_stricmp(item->itemvalue, "OFF") == 0)
			def->usedChannels = def->usedChannels & ~(1L << t);
		else
		{
			err_SetMsg(ERROR_DEF_UNKNOWNITEM, "unknown item %s = %s appears in [Channels] group", item->itemname, item->itemvalue);
			return false;
		}
	}
	return true;
}

static bool def_ParseItem_Settings(DEF_t* def, INI_ITEM_t* item) {
	if (ini_IsTimeItem(item, "Max PWM Duty", "us") == true)
		def->maxPWMDuty = ini_ParseTimeItem();
	else
	if (ini_IsTimeItem(item, "Min PWM Duty", "us") == true)
		def->minPWMDuty = ini_ParseTimeItem();
	else
	if (ini_IsTimeItem(item, "PWM Period", "us") == true)
		def->PWMPeriod = ini_ParseTimeItem();
	else
	if (ini_IsTimeItem(item, "Max Commands", NULL) == true)
		def->CMD_maxNum = ini_ParseTimeItem();
	else
	if (ini_IsTimeItem(item, "Max Actions", NULL) == true)
		def->ACT_maxNum = ini_ParseTimeItem();
	else
	if (ini_IsTimeItem(item, "Max Frames", NULL) == true)
		def->FRM_maxNum = ini_ParseTimeItem();
	else
	if (ini_IsTimeItem(item, "Max Sounds", NULL) == true)
		def->SND_maxNum = ini_ParseTimeItem();
	else
	if ((ini_IsItem(item, "Initial Command") == true) && (strlen(item->itemvalue) > 0))
	{
		if (strlen(item->itemvalue) > CMD_MAXNAMELEN)
			errmsg("WARNING: item %s must has value <= %d chars!\n", item->itemname, CMD_MAXNAMELEN);

		strncpy(def->initCMDName, item->itemvalue, CMD_MAXNAMELEN);
		def->initCMDName[CMD_MAXNAMELEN] = '\0';
	}
	else
	{
		err_SetMsg(ERROR_DEF_UNKNOWNITEM, "unknown item %s = %s appears in [Settings] group", item->itemname, item->itemvalue);
		return false;
	}

	return true;
}


static bool def_ReadSettings(char* filename, DEF_t* def) {
    FILEIO*    fp;
    INI_ITEM_t item;
	int  i;

    #define DEFGROUP_NONE      (0)
    #define DEFGROUP_UNKNOWN   (1)
    #define DEFGROUP_INFO      (2)
    #define DEFGROUP_FILES     (3)
    #define DEFGROUP_CHANNELS  (4)
    #define DEFGROUP_SETTINGS  (5)
    int gflag = DEFGROUP_NONE;

	def->CMD_maxNum = 999;
	def->CMD_num    = 0;
	def->cmdPool    = NULL;
	def->initCMD    = -1;
	def->initCMDName[0] = '\0';
	def->ACT_maxNum = 9999;
	def->actPool    = NULL;
	def->FRM_maxNum = 9999;
	def->frmPool    = NULL;
	def->SND_maxNum = 999;
	def->maxPWMDuty = FRM_maxPWMDuty;
	def->minPWMDuty = FRM_minPWMDuty;
	def->PWMPeriod  = 10000; //10ms
	def->usedChannels = 0xffffffffL;
	for (i=0; i<32; i++) def->channelMapping[i] = i;


	if ((fp = ini_FileOpen(demofile_GetPath(filename))) == NULL)
    {
        err_SetMsg(ERROR_DEMOFILE_OPENFAIL, "cannot open the definition file: %s", filename);
        return false;
    }

    while (ini_ReadNextItem(fp, &item) == true)
    {
		switch(item.type)
        {
            case INI_GROUPTITLE:
                gflag = DEFGROUP_UNKNOWN;

				if (ini_IsGroup(&item, "Info") == true)
					gflag = DEFGROUP_INFO;
				else
				if (ini_IsGroup(&item, "Files") == true)
					gflag = DEFGROUP_FILES;
				else
				if (ini_IsGroup(&item, "Channels") == true)
					gflag = DEFGROUP_CHANNELS;
				else
				if (ini_IsGroup(&item, "Settings") == true)
					gflag = DEFGROUP_SETTINGS;
				else
					errmsg("WARNING: unknown group [%s]!\n", item.itemname);
                break;
            case INI_GROUPITEM:
				switch(gflag)
				{
					case DEFGROUP_CHANNELS:
						if (def_ParseItem_Channels(def, &item) == false) goto END_READDEF_FAIL;
						break;
					case DEFGROUP_SETTINGS:
						if (def_ParseItem_Settings(def, &item) == false) goto END_READDEF_FAIL;
						break;
					case DEFGROUP_NONE:
						errmsg("WARNING: item %s = %s not in a group!\n", item.itemname, item.itemvalue);
						break;
				}
                break;
            case INI_UNKNOWNITEM:
				if (gflag == DEFGROUP_NONE)
                {
                    errmsg("WARNING: item %s not in a group!\n", item.itemname);
					break;
                }

				err_SetMsg(ERROR_DEF_UNKNOWNITEM, "unknown item %s", item.itemname);
				goto END_READDEF_FAIL;
        } //end switch(item...
    } //end while(ini_...

	ini_FileClose(fp);
	return true;

END_READDEF_FAIL:
    ini_FileClose(fp);
	return false;
}

static bool def_ReadFiles(char* filename, DEF_t* def) {
    FILEIO*    fp;
    INI_ITEM_t item;
    int gflag = DEFGROUP_NONE, i;

	FRM_maxPWMDuty = def->maxPWMDuty;
	FRM_minPWMDuty = def->minPWMDuty;

	fp = ini_FileOpen(demofile_GetPath(filename));
    while (ini_ReadNextItem(fp, &item) == true)
    {
		switch(item.type)
        {
            case INI_GROUPTITLE:
				gflag = (ini_IsGroup(&item, "Files") == true)? DEFGROUP_FILES : DEFGROUP_NONE;
                break;
            case INI_GROUPITEM:
				if (gflag != DEFGROUP_FILES) break;

				if ((ini_IsItem(&item, "CMD") == true) && (strlen(item.itemvalue) > 0))
				{
					showmsg("load command file: %s...", item.itemvalue);

					if (def->cmdPool == NULL)
					{
						def->cmdPool = (CMD_t**)mem_alloc(def->CMD_maxNum * sizeof(CMD_t*));
						demofile_InitCMD(def->cmdPool, def->CMD_maxNum);
					}
					def->CMD_num = demofile_ReadCMD(item.itemvalue, def->cmdPool, def->CMD_num, def->CMD_maxNum);
					if (def->CMD_num == -1) goto END_READDEFFILE_FAIL;

					showmsg("...success\n");
				}
				else
				if ((ini_IsItem(&item, "ACT") == true) && (strlen(item.itemvalue) > 0))
				{
					showmsg("load action file: %s...", item.itemvalue);

					if (def->actPool == NULL)
					{
						def->actPool = (ACT_t**)mem_alloc(def->ACT_maxNum * sizeof(ACT_t*));
						demofile_InitACT(def->actPool, def->ACT_maxNum);
					}
					if (demofile_ReadACT(item.itemvalue, def->actPool, def->ACT_maxNum) == false)
						goto END_READDEFFILE_FAIL;

					showmsg("...success\n");
				}
				else
				if ((ini_IsItem(&item, "Frame") == true) && (strlen(item.itemvalue) > 0))
				{
					showmsg("load frame file: %s...", item.itemvalue);

					if (def->frmPool == NULL)
					{
						def->frmPool = (unsigned long**)mem_alloc(def->FRM_maxNum * sizeof(unsigned long*));
						demofile_InitFRM(def->frmPool, def->FRM_maxNum);
					}
					if (demofile_ReadFRM(item.itemvalue, def->frmPool, def->FRM_maxNum) == false)
						goto END_READDEFFILE_FAIL;

					showmsg("...success\n");
				}
                break;
        } //end switch(item...
    } //end while(ini_...

	if (def->cmdPool == NULL)
	{
		err_SetMsg(ERROR_DEF_NOFILES, "no command file is declared");
		goto END_READDEFFILE_FAIL;
	}
	if (def->actPool == NULL)
	{
		err_SetMsg(ERROR_DEF_NOFILES, "no action file is declared");
		goto END_READDEFFILE_FAIL;
	}
	if (def->frmPool == NULL)
	{
		err_SetMsg(ERROR_DEF_NOFILES, "no frame file is declared");
		goto END_READDEFFILE_FAIL;
	}

	if (def->CMD_num == 0)
		errmsg("WARNING: No command is found, so you have no control anymore!\n");
	else
	if (strlen(def->initCMDName) > 0)
	{
		for (i=0; i<def->CMD_num; i++)
		{
			if (_stricmp(def->initCMDName, def->cmdPool[i]->name) == 0) //&&
			if (def->actPool[def->cmdPool[i]->actno] != NULL)
			{
				def->initCMD = i; //def->cmdPool[i]->actno;
				break;
			}
		}
		if (i == def->CMD_num) errmsg("WARNING: inital command %s is invalid!\n", def->initCMDName);
	}

	ini_FileClose(fp);
	return true;

END_READDEFFILE_FAIL:
	ini_FileClose(fp);
	demofile_FreeDEF(def);
	return false;
}


bool demofile_ReadDEF(char* filename, DEF_t* def) {
	if (def_ReadSettings(filename, def) == false) return false;
	if (def_ReadFiles(filename, def) == false) return false;
	return true;
}


void demofile_FreeDEF(DEF_t* def) {
	if (def->cmdPool != NULL)
	{
		demofile_FreeCMD(def->cmdPool, def->CMD_maxNum);
		def->cmdPool = NULL;
	}
	if (def->actPool != NULL)
	{
		demofile_FreeACT(def->actPool, def->ACT_maxNum);
		def->actPool = NULL;
	}
	if (def->frmPool != NULL)
	{
		demofile_FreeFRM(def->frmPool, def->FRM_maxNum);
		def->frmPool = NULL;
	}
}



char* DEMOFILE_demoDirectory = "";

static char DEMOFILE_bufpath[512];
char* demofile_GetPath(char* filepath) { //the user should not modify the return string
	char bufpath[512];

	strcpy(bufpath, filepath); //avoid the case where filepath == DEMOFILE_bufpath
	strcpy(DEMOFILE_bufpath, DEMOFILE_demoDirectory);
	return strcat(DEMOFILE_bufpath, bufpath);
}

